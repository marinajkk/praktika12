<?php require 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login=?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();
    if ($user && password_verify($pass, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['login']   = $user['login'];
        $_SESSION['role']    = $user['role'];
        header('Location: index.php');
        exit;
    }
    $error = 'Неверный логин или пароль';
}
?>
<!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Вход</title><link rel="stylesheet" href="style.css"></head><body>
<main class="container narrow">
    <h1>Вход</h1>
    <?php if ($error): ?><div class="alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
        <div class="form-group"><label>Логин</label><input type="text" name="login" required></div>
        <div class="form-group"><label>Пароль</label><input type="password" name="password" required></div>
        <button class="btn" type="submit">Войти</button>
        <p><a href="register.php">Регистрация</a></p>
    </form>
</main></body></html>