<?php require 'config.php'; requireLogin();

$appId = (int)($_GET['app_id'] ?? 0);
$stmt = $pdo->prepare("
    SELECT a.*, s.name AS status, e.title
    FROM applications a
    JOIN statuses s ON s.id = a.status_id
    JOIN events e ON e.id = a.event_id
    WHERE a.id = ? AND a.user_id = ?
");
$stmt->execute([$appId, $_SESSION['user_id']]);
$app = $stmt->fetch();

if (!$app) die('Заявка не найдена');
if ($app['status'] !== 'Завершено') die('Отзыв доступен только после завершения мероприятия. Текущий статус: ' . e($app['status']));

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = trim($_POST['text'] ?? '');
    $rating = (int)($_POST['rating'] ?? 0);
    if (strlen($text) < 5) $error = 'Текст отзыва — минимум 5 символов';
    elseif ($rating < 1 || $rating > 5) $error = 'Оценка от 1 до 5';

    if (!$error) {
        $stmt = $pdo->prepare("INSERT INTO reviews (application_id,text,rating) VALUES (?,?,?)");
        $stmt->execute([$appId, $text, $rating]);
        header('Location: my_applications.php'); exit;
    }
}
?>
<!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Отзыв</title><link rel="stylesheet" href="style.css"></head><body>
<main class="container narrow">
    <h1>Отзыв о «<?= e($app['title']) ?>»</h1>
    <?php if ($error): ?><div class="alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
        <div class="form-group">
            <label>Оценка *</label>
            <select name="rating" required>
                <option value="5">⭐⭐⭐⭐⭐ Отлично</option>
                <option value="4">⭐⭐⭐⭐ Хорошо</option>
                <option value="3">⭐⭐⭐ Удовлетворительно</option>
                <option value="2">⭐⭐ Плохо</option>
                <option value="1">⭐ Очень плохо</option>
            </select>
        </div>
        <div class="form-group">
            <label>Текст отзыва *</label>
            <textarea name="text" rows="4" required placeholder="Поделитесь впечатлениями..."></textarea>
        </div>
        <button class="btn" type="submit">Отправить отзыв</button>
    </form>
</main></body></html>