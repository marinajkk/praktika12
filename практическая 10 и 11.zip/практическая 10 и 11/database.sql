CREATE DATABASE IF NOT EXISTS conferences_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE conferences_db;

-- Пользователи
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user'
);

-- Мероприятия
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    description TEXT
);

-- Статусы
CREATE TABLE statuses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL
);

INSERT INTO statuses (name) VALUES ('Новая'), ('Назначено'), ('Завершено');

-- Заявки
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    event_id INT NOT NULL,
    status_id INT NOT NULL DEFAULT 1,
    room VARCHAR(50),
    payment VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id),
    FOREIGN KEY (status_id) REFERENCES statuses(id)
);

-- Отзывы (1:1 к заявке)
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT UNIQUE NOT NULL,
    text TEXT NOT NULL,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
);

-- Демо-данные
INSERT INTO events (title, event_date, location, description) VALUES
('Научная конференция «IT-2026»', '2026-05-15', 'Москва, МГУ', 'Конференция по информационным технологиям'),
('Симпозиум «Биотехнологии будущего»', '2026-06-20', 'Санкт-Петербург, СПбГУ', 'Современные биотехнологии'),
('Форум «Цифровая экономика»', '2026-09-10', 'Казань, КФУ', 'Цифровая трансформация бизнеса');

-- Админ (пароль: admin123)
INSERT INTO users (login, password_hash, email, phone, role) VALUES
('admin', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlCS4bZJ18JuywdBFQq3fW7v8F6F6G', 'admin@conf.ru', '+79990000000', 'admin');