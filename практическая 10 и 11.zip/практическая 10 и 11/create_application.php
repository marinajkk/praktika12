<?php require 'config.php'; requireLogin();
$events = $pdo->query("SELECT * FROM events")->fetchAll();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_id = (int)($_POST['event_id'] ?? 0);
    $room     = $_POST['room'] ?? '';
    $payment  = $_POST['payment'] ?? '';
    if (!$event_id || !$room || !$payment) {
        $error = 'Заполните все поля';
    } else {
        $stmt = $pdo->prepare("INSERT INTO applications (user_id,event_id,status_id,room,payment) VALUES (?,?,1,?,?)");
        $stmt->execute([$_SESSION['user_id'], $event_id, $room, $payment]);
        header('Location: my_applications.php');
        exit;
    }
}
?>
<!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Создание заявки</title><link rel="stylesheet" href="style.css"></head><body>
<main class="container narrow">
    <h1>Подача заявки</h1>
    <?php if ($error): ?><div class="alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
        <div class="form-group">
            <label>Мероприятие *</label>
            <select name="event_id" required>
                <option value="">— Выберите —</option>
                <?php foreach ($events as $ev): ?>
                    <option value="<?= $ev['id'] ?>" <?= (($_GET['event_id']??'')==$ev['id']?'selected':'') ?>>
                        <?= e($ev['title']) ?> (<?= e($ev['event_date']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Помещение *</label>
            <select name="room" required>
                <option value="">— Выберите —</option>
                <option>A-101 (100 мест)</option>
                <option>B-202 (50 мест)</option>
                <option>C-303 (200 мест)</option>
            </select>
        </div>
        <div class="form-group">
            <label>Способ оплаты *</label>
            <select name="payment" required>
                <option value="">— Выберите —</option>
                <option value="card">Банковская карта</option>
                <option value="cash">Наличные</option>
                <option value="invoice">Безналичный расчёт</option>
                <option value="free">Бесплатно</option>
            </select>
        </div>
        <button class="btn" type="submit">Отправить заявку</button>
    </form>
</main></body></html>