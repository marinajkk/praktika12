<?php require 'config.php'; requireAdmin();

// Смена статуса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['app_id'], $_POST['status_id'])) {
    $stmt = $pdo->prepare("UPDATE applications SET status_id=? WHERE id=?");
    $stmt->execute([(int)$_POST['status_id'], (int)$_POST['app_id']]);
    header('Location: admin.php'); exit;
}

$filterStatus = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');

$sql = "SELECT a.*, u.login, e.title, s.name AS status
        FROM applications a
        JOIN users u ON u.id = a.user_id
        JOIN events e ON e.id = a.event_id
        JOIN statuses s ON s.id = a.status_id
        WHERE 1=1";
$params = [];
if ($filterStatus !== 'all') { $sql .= " AND s.name = ?"; $params[] = $filterStatus; }
if ($search !== '') { $sql .= " AND (u.login LIKE ? OR e.title LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= " ORDER BY a.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$apps = $stmt->fetchAll();
$statuses = $pdo->query("SELECT * FROM statuses")->fetchAll();
?>
<!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Админка</title><link rel="stylesheet" href="style.css"></head><body>
<header class="navbar">
    <div class="logo">Конференции.РФ — Админ</div>
    <nav><a href="index.php">Главная</a><a href="logout.php">Выйти</a></nav>
</header>
<main class="container">
    <h1>Управление заявками</h1>

    <form method="get" class="filters">
        <input type="text" name="search" placeholder="🔍 Поиск по логину/мероприятию" value="<?= e($search) ?>">
        <select name="status">
            <option value="all">Все статусы</option>
            <?php foreach ($statuses as $s): ?>
                <option value="<?= e($s['name']) ?>" <?= $filterStatus===$s['name']?'selected':'' ?>><?= e($s['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn" type="submit">Фильтровать</button>
    </form>

    <div class="cards-grid">
        <?php foreach ($apps as $a): ?>
            <div class="card" data-status="<?= e($a['status']) ?>">
                <h3><?= e($a['title']) ?></h3>
                <p><strong>Участник:</strong> <?= e($a['login']) ?></p>
                <p><strong>Помещение:</strong> <?= e($a['room']) ?></p>
                <p><strong>Оплата:</strong> <?= e($a['payment']) ?></p>
                <span class="status-badge status-<?= e($a['status']) ?>"><?= e($a['status']) ?></span>

                <form method="post" class="status-form">
                    <input type="hidden" name="app_id" value="<?= $a['id'] ?>">
                    <select name="status_id">
                        <?php foreach ($statuses as $s): ?>
                            <option value="<?= $s['id'] ?>" <?= $s['name']===$a['status']?'selected':'' ?>><?= e($s['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="btn-small" type="submit">Сменить</button>
                </form>
            </div>
        <?php endforeach; ?>
        <?php if (!$apps): ?><p>Заявок не найдено.</p><?php endif; ?>
    </div>
</main></body></html>