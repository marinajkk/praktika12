<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Конференции.РФ</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="navbar">
    <div class="logo">Конференции.РФ</div>
    <nav>
        <?php if (!empty($_SESSION['user_id'])): ?>
            <a href="my_applications.php">Мои заявки</a>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="admin.php">Админка</a>
            <?php endif; ?>
            <a href="logout.php">Выйти</a>
        <?php else: ?>
            <a href="login.php">Войти</a>
            <a href="register.php">Регистрация</a>
        <?php endif; ?>
    </nav>
</header>

<main class="container">
    <h1>Ближайшие конференции</h1>
    <div class="cards-grid">
        <?php
        $events = $pdo->query("SELECT * FROM events ORDER BY event_date")->fetchAll();
        foreach ($events as $ev): ?>
            <div class="card">
                <h3><?= e($ev['title']) ?></h3>
                <p><strong>Дата:</strong> <?= e($ev['event_date']) ?></p>
                <p><strong>Место:</strong> <?= e($ev['location']) ?></p>
                <p><?= e($ev['description']) ?></p>
                <?php if (!empty($_SESSION['user_id'])): ?>
                    <a class="btn" href="create_application.php?event_id=<?= $ev['id'] ?>">Подать заявку</a>
                <?php else: ?>
                    <a class="btn" href="login.php">Войдите, чтобы подать заявку</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</main>
</body>
</html>