<?php require 'config.php';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if (strlen($login) < 3) $errors['login'] = 'Логин — минимум 3 символа';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Некорректный email';
    if (strlen(preg_replace('/\D/', '', $phone)) < 10) $errors['phone'] = 'Телефон — минимум 10 цифр';
    if (strlen($pass) < 8) $errors['password'] = 'Пароль — минимум 8 символов';

    // Проверка уникальности
    $stmt = $pdo->prepare("SELECT id FROM users WHERE login=? OR email=?");
    $stmt->execute([$login, $email]);
    if ($stmt->fetch()) $errors['common'] = 'Логин или email уже заняты';

    if (empty($errors)) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (login,password_hash,email,phone) VALUES (?,?,?,?)");
        $stmt->execute([$login, $hash, $email, $phone]);
        header('Location: login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Регистрация</title><link rel="stylesheet" href="style.css">
</head><body>
<main class="container narrow">
    <h1>Регистрация</h1>
    <?php if (!empty($errors['common'])): ?><div class="alert-error"><?= e($errors['common']) ?></div><?php endif; ?>
    <form method="post" novalidate>
        <div class="form-group">
            <label>Логин *</label>
            <input type="text" name="login" value="<?= e($login ?? '') ?>" class="<?= isset($errors['login'])?'invalid':'' ?>">
            <span class="error"><?= e($errors['login'] ?? '') ?></span>
        </div>
        <div class="form-group">
            <label>Email *</label>
            <input type="email" name="email" value="<?= e($email ?? '') ?>" class="<?= isset($errors['email'])?'invalid':'' ?>">
            <span class="error"><?= e($errors['email'] ?? '') ?></span>
        </div>
        <div class="form-group">
            <label>Телефон *</label>
            <input type="tel" name="phone" value="<?= e($phone ?? '') ?>" class="<?= isset($errors['phone'])?'invalid':'' ?>">
            <span class="error"><?= e($errors['phone'] ?? '') ?></span>
        </div>
        <div class="form-group">
            <label>Пароль *</label>
            <input type="password" name="password" class="<?= isset($errors['password'])?'invalid':'' ?>">
            <span class="error"><?= e($errors['password'] ?? '') ?></span>
        </div>
        <button class="btn" type="submit">Зарегистрироваться</button>
        <p><a href="login.php">Уже есть аккаунт? Войти</a></p>
    </form>
</main></body></html>