<?php require 'config.php'; requireLogin();
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM applications WHERE id=? AND user_id=?");
    $stmt->execute([(int)$_GET['delete'], $_SESSION['user_id']]);
    header('Location: my_applications.php'); exit;
}
$stmt = $pdo->prepare("
    SELECT a.*, e.title, s.name AS status, r.id AS review_id
    FROM applications a
    JOIN events e ON e.id = a.event_id
    JOIN statuses s ON s.id = a.status_id
    LEFT JOIN reviews r ON r.application_id = a.id
    WHERE a.user_id = ?
    ORDER BY a.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$apps = $stmt->fetchAll();
?>
<!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Мои заявки</title><link rel="stylesheet" href="style.css"></head><body>
<header class="navbar">
    <div class="logo">Конференции.РФ</div>
    <nav>
        <a href="index.php">Главная</a>
        <a href="logout.php">Выйти</a>
    </nav>
</header>
<main class="container">
    <h1>Мои заявки</h1>
    <div class="cards-grid">
        <?php foreach ($apps as $a): ?>
            <div class="card" data-status="<?= e($a['status']) ?>">
                <h3><?= e($a['title']) ?></h3>
                <p><strong>Помещение:</strong> <?= e($a['room']) ?></p>
                <p><strong>Оплата:</strong> <?= e($a['payment']) ?></p>
                <span class="status-badge status-<?= e($a['status']) ?>"><?= e($a['status']) ?></span>
                <div class="card-actions">
                    <a class="btn-small" href="?delete=<?= $a['id'] ?>" onclick="return confirm('Удалить заявку?')">Удалить</a>
                    <?php if ($a['status'] === 'Завершено'): ?>
                        <?php if ($a['review_id']): ?>
                            <span class="reviewed">✔ Отзыв оставлен</span>
                        <?php else: ?>
                            <a class="btn-small btn-accent" href="review.php?app_id=<?= $a['id'] ?>">Оставить отзыв</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (!$apps): ?><p>У вас пока нет заявок.</p><?php endif; ?>
    </div>
</main></body></html>