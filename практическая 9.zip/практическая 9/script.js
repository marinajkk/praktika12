/* =========================================================
   1. ВАЛИДАЦИЯ ФОРМЫ СОЗДАНИЯ ЗАЯВКИ (index.html)
   ========================================================= */
const form = document.getElementById('applicationForm');

if (form) {
    const showError = (fieldId, msg) => {
        const input = document.getElementById(fieldId);
        const err = document.getElementById('error-' + fieldId);
        if (msg) {
            input.classList.add('invalid');
            err.textContent = msg;
        } else {
            input.classList.remove('invalid');
            err.textContent = '';
        }
    };

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        let isValid = true;

        // ФИО: минимум 5 символов, только буквы и пробелы
        const fullname = document.getElementById('fullname').value.trim();
        if (fullname.length < 5) {
            showError('fullname', 'Введите ФИО (минимум 5 символов)');
            isValid = false;
        } else if (!/^[А-Яа-яЁёA-Za-z\s]+$/.test(fullname)) {
            showError('fullname', 'Только буквы и пробелы');
            isValid = false;
        } else showError('fullname', '');

        // Email: регулярное выражение
        const email = document.getElementById('email').value.trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            showError('email', 'Некорректный email (пример: user@mail.ru)');
            isValid = false;
        } else showError('email', '');

        // Телефон: минимум 10 цифр
        const phone = document.getElementById('phone').value.trim();
        if (phone.replace(/\D/g, '').length < 10) {
            showError('phone', 'Введите телефон (минимум 10 цифр)');
            isValid = false;
        } else showError('phone', '');

        // Выпадающие списки: обязательный выбор
        ['event', 'room', 'payment'].forEach(id => {
            const val = document.getElementById(id).value;
            if (!val) {
                showError(id, 'Пожалуйста, выберите значение');
                isValid = false;
            } else showError(id, '');
        });

        // Если всё ок — показываем сообщение
        if (isValid) {
            document.getElementById('successMessage').style.display = 'block';
            form.reset();
            setTimeout(() => {
                document.getElementById('successMessage').style.display = 'none';
            }, 4000);
        }
    });
}

/* =========================================================
   2. ПАНЕЛЬ АДМИНИСТРАТОРА: КАРТОЧКИ + ФИЛЬТРАЦИЯ (admin.html)
   ========================================================= */
const cardsContainer = document.getElementById('cardsContainer');

if (cardsContainer) {
    // Демо-данные
    const applications = [
        { id: 1, name: 'Иванов Иван Иванович', event: 'IT-2026', status: 'Новая', room: 'A-101', payment: 'card' },
        { id: 2, name: 'Петров Пётр Петрович', event: 'Биотехнологии', status: 'Назначено', room: 'B-202', payment: 'invoice' },
        { id: 3, name: 'Сидоров Сергей Сергеевич', event: 'Цифровая экономика', status: 'Завершено', room: 'C-303', payment: 'free' },
        { id: 4, name: 'Кузнецов Кирилл Кириллович', event: 'IT-2026', status: 'Новая', room: 'A-101', payment: 'cash' },
        { id: 5, name: 'Смирнова Анна Викторовна', event: 'Биотехнологии', status: 'Завершено', room: 'B-202', payment: 'card' },
    ];

    const renderCards = (list) => {
        cardsContainer.innerHTML = '';
        if (list.length === 0) {
            cardsContainer.innerHTML = '<p>Заявок не найдено.</p>';
            return;
        }
        list.forEach(app => {
            const card = document.createElement('div');
            card.className = 'card';
            card.dataset.status = app.status;
            card.innerHTML = `
                <h3>${app.name}</h3>
                <p><strong>Мероприятие:</strong> ${app.event}</p>
                <p><strong>Помещение:</strong> ${app.room}</p>
                <p><strong>Оплата:</strong> ${app.payment}</p>
                <span class="status-badge status-${app.status}">${app.status}</span>
            `;
            cardsContainer.appendChild(card);
        });
    };

    const applyFilters = () => {
        const search = document.getElementById('searchInput').value.toLowerCase();
        const status = document.getElementById('statusFilter').value;
        const event  = document.getElementById('eventFilter').value;

        const filtered = applications.filter(app => {
            const matchSearch = app.name.toLowerCase().includes(search) || app.event.toLowerCase().includes(search);
            const matchStatus = status === 'all' || app.status === status;
            const matchEvent  = event  === 'all' || app.event === event;
            return matchSearch && matchStatus && matchEvent;
        });
        renderCards(filtered);
    };

    document.getElementById('searchInput').addEventListener('input', applyFilters);
    document.getElementById('statusFilter').addEventListener('change', applyFilters);
    document.getElementById('eventFilter').addEventListener('change', applyFilters);

    renderCards(applications); // Первичная отрисовка
}

/* =========================================================
   3. ОТЗЫВ ТОЛЬКО ПОСЛЕ ЗАВЕРШЕНИЯ (reviews.html)
   ========================================================= */
const applicationSelect = document.getElementById('applicationSelect');

if (applicationSelect) {
    const reviewBlock = document.getElementById('reviewBlock');
    const notAllowedBlock = document.getElementById('notAllowedBlock');
    const currentStatus = document.getElementById('currentStatus');

    applicationSelect.addEventListener('change', () => {
        const selected = applicationSelect.options[applicationSelect.selectedIndex];
        const status = selected.getAttribute('data-status');

        if (!applicationSelect.value) {
            reviewBlock.style.display = 'none';
            notAllowedBlock.style.display = 'none';
            return;
        }

        if (status === 'Завершено') {
            reviewBlock.style.display = 'block';
            notAllowedBlock.style.display = 'none';
        } else {
            reviewBlock.style.display = 'none';
            notAllowedBlock.style.display = 'block';
            currentStatus.textContent = status;
        }
    });

    // Отправка отзыва
    document.getElementById('submitReview').addEventListener('click', () => {
        const text = document.getElementById('reviewText').value.trim();
        if (text.length < 5) {
            alert('Напишите отзыв (минимум 5 символов).');
            return;
        }
        document.getElementById('reviewSuccess').style.display = 'block';
        document.getElementById('reviewText').value = '';
        setTimeout(() => {
            document.getElementById('reviewSuccess').style.display = 'none';
        }, 3000);
    });
}